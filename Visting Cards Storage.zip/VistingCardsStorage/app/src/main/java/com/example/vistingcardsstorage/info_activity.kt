package com.example.vistingcardsstorage

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

@Suppress("DEPRECATION")
class InfoActivity(private val REQUEST_IMAGE_CAPTURE: Int = 100) : AppCompatActivity() {
    private lateinit var imageView:ImageView
    private lateinit var button:Button
    private lateinit var button1:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info2)

        imageView = findViewById(R.id.image_save)
        button = findViewById(R.id.btn_add_photos)
        button1 = findViewById(R.id.button2)

        button1.setOnClickListener{
            Toast.makeText(this,"Data Saved Succesfully!!",Toast.LENGTH_SHORT).show()
        }

        button.setOnClickListener{
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            try{

                startActivityForResult(takePictureIntent,REQUEST_IMAGE_CAPTURE)
            }catch(e: ActivityNotFoundException){
                Toast.makeText(this,"Error: "+e.localizedMessage,Toast.LENGTH_SHORT).show()
            }
        }

    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?){
        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK){
            val imageBitmap= data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(imageBitmap)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}